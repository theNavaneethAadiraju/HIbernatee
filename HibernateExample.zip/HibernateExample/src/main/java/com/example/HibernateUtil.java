package com.example;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateUtil {
    private static final SessionFactory sessionFactory;

    static {
        try {
            Configuration configuration = new Configuration();
            
            // Set Hibernate properties
            configuration.setProperty(Environment.DRIVER, "org.h2.Driver");
            configuration.setProperty(Environment.URL, "jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1");
            configuration.setProperty(Environment.USER, "sa");
            configuration.setProperty(Environment.PASS, "");
            configuration.setProperty(Environment.DIALECT, "org.hibernate.dialect.H2Dialect");
            configuration.setProperty(Environment.HBM2DDL_AUTO, "update");
            configuration.setProperty(Environment.SHOW_SQL, "true");
            
//            configuration.setProperty(Environment.USE_SECOND_LEVEL_CACHE, "true");
//            configuration.setProperty(Environment.CACHE_REGION_FACTORY, "org.hibernate.cache.ehcache.EhCacheRegionFactory.class");

            // Add annotated classes
            configuration.addAnnotatedClass(Person.class);
            configuration.addAnnotatedClass(Name.class);

            // Build service registry
            ServiceRegistry serviceRegistry = new ServiceRegistryBuilder()
                .applySettings(configuration.getProperties())
                .buildServiceRegistry();

            // Build session factory
            sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
