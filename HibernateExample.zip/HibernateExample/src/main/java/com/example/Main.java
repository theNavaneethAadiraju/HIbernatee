//package com.example;
//
//
//
//import org.hibernate.*;
//import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
//import org.hibernate.cfg.Configuration;
//import org.hibernate.service.ServiceRegistry;
//import org.hibernate.service.ServiceRegistryBuilder;
//
//public class Main {
//    public static void main(String[] args) {
//    	Configuration con= new Configuration().configure().addAnnotatedClass(Person.class);
//    	ServiceRegistry reg= new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
//        SessionFactory sessionFactory = con.buildSessionFactory(reg);
//        Session session = sessionFactory.openSession();
//
//        Transaction transaction = session.beginTransaction();
//
//        Name name = new Name();
//        name.setFirstName("John");
//        name.setMiddleName("F.");
//        name.setLastName("Doe");
//
//        Person person = new Person();
//        person.setName(name);
//        session.save(person);
//
//        transaction.commit();
//        session.close();
//
//        System.out.println("Person saved with ID: " + person.getId());
//
//        sessionFactory.close();
//    }
//}
//
package com.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.io.Serializable;
import java.sql.SQLException;

import org.h2.tools.Server;

public class Main {
	public static void main(String[] args) {
		try {
			Server server = Server.createWebServer("-web", "-webAllowOthers", "-webDaemon").start();

			System.out.println("H2 Console URL: http://192.168.0.129:8082");
			Person value = null;

			SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
			Session session = sessionFactory.openSession();
			

			try {
				
				Transaction transaction = session.beginTransaction();
				
//
				Name name = new Name();
//
				name.setFirstName("John");
				name.setMiddleName("F");
				name.setLastName("Doe");

				Person person = new Person();
				person.setId(4);
				person.setAge(22);
//				
				person.setName(name);
//				
				session.save(person);
				
//				value= (Person)session.get(Person.class, 4);
//				System.out.println(value);
//				value= (Person)session.get(Person.class, 4);
//				System.out.println(value);
				transaction.commit();
				
				
//				Serializable s = session.save(person);
//				Integer id =(Integer)s;
//				System.out.println(id);
				
				
				
				session.close();
				
				
//				Session session2 = sessionFactory.openSession();
//				session2.beginTransaction();
//				
//				value= (Person)session2.get(Person.class, 4);
//				System.out.println(value);
//				value= (Person)session2.get(Person.class, 4);
//				System.out.println(value);
//				
//				
//				transaction.commit();
//				session2.close();
				
				
				
				
				
//				System.out.println("Person saved with ID: " + person.getId());
//				System.out.println("Person saved with ID: " + person.getId());
//				Person person1 = new Person();
//				person1= (Person)session.get(Person.class, 3);
//				System.out.println("Person saved with ID: " + person1.getId());
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
//				session.close();
//				sessionFactory.close();
			}
			// Keep console server running until program exit
			Runtime.getRuntime().addShutdownHook(new Thread(() -> {
				server.stop();
			}));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}