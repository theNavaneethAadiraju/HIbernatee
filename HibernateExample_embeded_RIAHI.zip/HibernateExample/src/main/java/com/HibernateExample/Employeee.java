package com.HibernateExample;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="EMP_DETAILS")
public class Employeee {
	

	@Id
	private int eid ;
	@Embedded
	private FName fullname;
	
	@Column(name="emp_address",nullable = false)
	private String address;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public FName getFullname() {
		return fullname;
	}
	public void setFullname(FName fullname) {
		this.fullname = fullname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Employeee [eid=" + eid + ", fullname=" + fullname + ", address=" + address + "]";
	}
	

	

	
	

}
