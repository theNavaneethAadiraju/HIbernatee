package com.HibernateExample;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class App {

    public static void main(String[] args) {

    	FName fn = new FName();
    	fn.setLname("thomas");
    	fn.setMname("John");
    	fn.setSname("L");
    	
        Employeee emp = new Employeee();
        emp.setEid(5);
        emp.setFullname(fn);
        emp.setAddress("Bangalore");
        
//        Employeee emp1 = new Employeee();
//        
//        emp1.setEid(6);
//        emp1.setEname("mark");
//        emp1.setAddress("USA");

        Configuration cf = new Configuration()
                .configure()
                .addAnnotatedClass(Employeee.class);

        ServiceRegistry reg = new ServiceRegistryBuilder()
                .applySettings(cf.getProperties())
                .buildServiceRegistry();

        SessionFactory sf = cf.buildSessionFactory(reg);

        Session s = sf.openSession();
        Transaction t = s.beginTransaction();

        s.save(emp);
        //s.save(emp1);

        t.commit();
        
//        //READ
//        Employeee empread= (Employeee) s.get(Employeee.class, 1);
//        System.out.println(empread);
//        
//        // UPDATE
//        Employeee empupdate= (Employeee) s.get(Employeee.class, 1);
//        empupdate.setAddress("Australia");
        
        t.commit();

        s.close();
        sf.close();
    }
}
