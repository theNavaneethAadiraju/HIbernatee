package com.example.test.HibernateAll;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateExample {

    public static void main(String[] args) {
    	
        // Setup Hibernate SessionFactory
        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();

        // Save an entity
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        
        Address address = new Address();
        address.setStreet("123 Elm Street");
        address.setCity("Springfield");
        address.setZipcode("12345");

        Person person = new Person();
        person.setName("John Doe");
        person.setAddress(address);
        session.save(person);
        tx.commit();
        session.close();

        // Update the entity
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        
        Person personToUpdate = session.get(Person.class, person.getId());
        personToUpdate.setName("Jane Doe");
        Address newAddress = new Address();
        newAddress.setStreet("456 Oak Avenue");
        newAddress.setCity("Shelbyville");
        newAddress.setZipcode("67890");
        personToUpdate.setAddress(newAddress);
        session.update(personToUpdate);
        tx.commit();
        session.close();

        // Save or update the entity
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        
        Person personToSaveOrUpdate = new Person();
        personToSaveOrUpdate.setId(person.getId()); // Ensure ID exists for update
        personToSaveOrUpdate.setName("John Smith");
        personToSaveOrUpdate.setAddress(new Address()); // Set a new address
        session.saveOrUpdate(personToSaveOrUpdate);
        tx.commit();
        session.close();

        // Merge the entity
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        
        Person personToMerge = new Person();
        personToMerge.setId(person.getId()); // Ensure ID exists for update
        personToMerge.setName("John Doe Again");
        Address mergedAddress = new Address();
        mergedAddress.setStreet("789 Maple Road");
        mergedAddress.setCity("Capitol City");
        mergedAddress.setZipcode("11223");
        personToMerge.setAddress(mergedAddress);
        Person mergedPerson = (Person) session.merge(personToMerge);
        tx.commit();
        session.close();

        // Persist the entity
        session = sessionFactory.openSession();
        tx = session.beginTransaction();
        
        Person personToPersist = new Person();
        personToPersist.setName("Michael Scott");
        Address addressToPersist = new Address();
        addressToPersist.setStreet("101 Pine Street");
        addressToPersist.setCity("Scranton");
        addressToPersist.setZipcode("12321");
        personToPersist.setAddress(addressToPersist);
        session.persist(personToPersist);
        tx.commit();
        session.close();

        // Close SessionFactory
        sessionFactory.close();
    }
}
